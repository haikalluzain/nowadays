<?php 
//    header('Location: public');
     echo "Blah blah";
?>
